var classpixi_1_1pixix_1_1PixiError =
[
    [ "__init__", "classpixi_1_1pixix_1_1PixiError.html#a8badc259c5d565c9c2dec46618416265", null ],
    [ "result", "classpixi_1_1pixix_1_1PixiError.html#aab45414c6bc010c0c4009e6a6d17f6bc", null ]
];