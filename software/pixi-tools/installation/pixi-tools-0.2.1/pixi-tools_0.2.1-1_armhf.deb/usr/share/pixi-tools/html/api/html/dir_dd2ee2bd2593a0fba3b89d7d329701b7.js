var dir_dd2ee2bd2593a0fba3b89d7d329701b7 =
[
    [ "gpio.c", "libpixi_2pi_2gpio_8c.html", "libpixi_2pi_2gpio_8c" ],
    [ "gpio.h", "gpio_8h.html", "gpio_8h" ],
    [ "spi.c", "libpixi_2pi_2spi_8c.html", "libpixi_2pi_2spi_8c" ],
    [ "spi.h", "spi_8h.html", "spi_8h" ]
];