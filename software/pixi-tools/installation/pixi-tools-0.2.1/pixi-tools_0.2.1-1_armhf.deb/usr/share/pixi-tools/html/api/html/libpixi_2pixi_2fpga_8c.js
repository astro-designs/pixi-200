var libpixi_2pixi_2fpga_8c =
[
    [ "CCLK_PIN", "libpixi_2pixi_2fpga_8c.html#a3b6c4b6a1a007f98a6f8b2e99b18bb95", null ],
    [ "DATA_PIN", "libpixi_2pixi_2fpga_8c.html#adad67fe595ea440c8f8247ec2cddf070", null ],
    [ "HIGH", "libpixi_2pixi_2fpga_8c.html#a5bb885982ff66a2e0a0a45a8ee9c35e2", null ],
    [ "INIT_PIN", "libpixi_2pixi_2fpga_8c.html#a885e4c51dcc91fcae14dadc2d564f270", null ],
    [ "INPUT", "libpixi_2pixi_2fpga_8c.html#a1bb283bd7893b9855e2f23013891fc82", null ],
    [ "LOW", "libpixi_2pixi_2fpga_8c.html#ab811d8c6ff3a505312d3276590444289", null ],
    [ "OUTPUT", "libpixi_2pixi_2fpga_8c.html#a61a3c9a18380aafb6e430e79bf596557", null ],
    [ "PROG_PIN", "libpixi_2pixi_2fpga_8c.html#a8aaceef1e80ae3b6c312a3748f1eea55", null ],
    [ "digitalRead", "libpixi_2pixi_2fpga_8c.html#ad805b2ceb0c0efd0f7c0d98d2564f103", null ],
    [ "digitalWrite", "libpixi_2pixi_2fpga_8c.html#a70bd61231b812b6ae989293293dbc7aa", null ],
    [ "pinMode", "libpixi_2pixi_2fpga_8c.html#ad75c887babbd1e571f24b97a1d9b07ee", null ],
    [ "pixi_pixiFpgaGetBuildTime", "libpixi_2pixi_2fpga_8c.html#gaee8eefaa11365b14180b9a4e18a4fe78", null ],
    [ "pixi_pixiFpgaGetVersion", "libpixi_2pixi_2fpga_8c.html#ga5a3f4bc84f58dd1b7cca90f5da1d3e2b", null ],
    [ "pixi_pixiFpgaLoadBuffer", "libpixi_2pixi_2fpga_8c.html#ga239eedd0597485b9b9ba5a595d5f578e", null ],
    [ "pixi_pixiFpgaLoadFile", "libpixi_2pixi_2fpga_8c.html#gabdee08ccba431774b5492d47fae96af9", null ],
    [ "pixi_pixiFpgaVersionToTime", "libpixi_2pixi_2fpga_8c.html#ga9db1bb9e7ada76b11a18547f0fdc1a80", null ],
    [ "versionPart", "libpixi_2pixi_2fpga_8c.html#aef7ae3685d9a0ccb76f20075c11a3ee6", null ]
];