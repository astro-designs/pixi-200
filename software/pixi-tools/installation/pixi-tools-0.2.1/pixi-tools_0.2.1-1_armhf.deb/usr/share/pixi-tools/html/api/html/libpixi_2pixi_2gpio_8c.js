var libpixi_2pixi_2gpio_8c =
[
    [ "pixi_pixiGpioSetMode", "libpixi_2pixi_2gpio_8c.html#ga96b98196523de0e46cb6a8eb99e54ef0", null ],
    [ "pixi_pixiGpioSetPinMode", "libpixi_2pixi_2gpio_8c.html#gab77bae72508c75391ecc15b9b578b539", null ],
    [ "pixi_pixiGpioWritePin", "libpixi_2pixi_2gpio_8c.html#ga45e097e063613dd75f7eada46dead77f", null ],
    [ "setGpioMode", "libpixi_2pixi_2gpio_8c.html#ad970b56af9047e433da1ea1a2a88413e", null ]
];