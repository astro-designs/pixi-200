var libpixi_8c =
[
    [ "SYS_GPIO", "libpixi_8c.html#a0fc5fce0ad5f4683deb946e5b2991260", null ],
    [ "LIBPIXI_CONSTRUCTOR", "libpixi_8c.html#a0a78977815a0285b1e80ec759f11ec04", null ],
    [ "pixi_getLibVersion", "libpixi_8c.html#ga79c7bd4369da4002a80700d096143fa9", null ],
    [ "pixi_getPiBoardRevision", "libpixi_8c.html#gaaf02a4deb5b4900bf3320e5d0a21223b", null ],
    [ "pixi_getPiBoardVersion", "libpixi_8c.html#ga6bd1a557d6172b402a8e4067d880e86e", null ],
    [ "pixi_initLib", "libpixi_8c.html#gac2a3c18650b8b2a4eeb44f5411a52a8a", null ],
    [ "boardRevision", "libpixi_8c.html#ac3c3fad53b6da966378972eead1612e6", null ],
    [ "boardVersion", "libpixi_8c.html#ac169fc525f5348da3daa580e4c990a9e", null ]
];