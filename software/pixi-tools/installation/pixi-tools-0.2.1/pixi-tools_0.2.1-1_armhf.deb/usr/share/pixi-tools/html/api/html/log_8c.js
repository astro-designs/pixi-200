var log_8c =
[
    [ "getLevelColor", "log_8c.html#a84a3587d5c5126f6eefff6c2df924ed7", null ],
    [ "pixi_logError", "log_8c.html#ga5c98ea78f8781d7536a75cfc22248b4e", null ],
    [ "pixi_logInit", "log_8c.html#ga130915424f476d53bf56450d4b54a194", null ],
    [ "pixi_logLevelToStr", "log_8c.html#ga39a7f29332f277e97177366879ac2b02", null ],
    [ "pixi_logPrint", "log_8c.html#ga37d2a7c720c6a1dc1af4c8e254a76cfe", null ],
    [ "pixi_strToLogLevel", "log_8c.html#gad6b0089bbf5c40a58c0b3f549d98f4ca", null ],
    [ "prefixLog", "log_8c.html#a92031c0c371d62b138393e2560e539f0", null ],
    [ "useAnsiColors", "log_8c.html#ad00741e8b5b215cfc6e40aaa63590d75", null ],
    [ "AnsiBold", "log_8c.html#ac61ccc7e40eb4fe2c2955f09d5f86b8c", null ],
    [ "AnsiBoldRed", "log_8c.html#a603be845bf907614f1dd72ddad1fc059", null ],
    [ "AnsiGreen", "log_8c.html#acccfe8e6db405f31c3361034e71ffab7", null ],
    [ "AnsiRed", "log_8c.html#a434442f971d4b3d02afa2bc18e3add0e", null ],
    [ "AnsiReset", "log_8c.html#a6843d4fd7ec43071f869b5996f2f1a13", null ],
    [ "levelColors", "log_8c.html#a441cc10d45be2e0fe86b2db3e369c712", null ],
    [ "pixi_logColors", "log_8c.html#gac3c84ff1c45411fdb4bf96dcd7daa84b", null ],
    [ "pixi_logLevel", "log_8c.html#ga937048ba147049b4b7437eb915688359", null ]
];