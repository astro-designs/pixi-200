var pio_2spi_8c =
[
    [ "monitorButtonsFn", "pio_2spi_8c.html#a0f7db1003aa159759f33ae89b94d8654", null ],
    [ "monitorSpi", "pio_2spi_8c.html#a8ac57c03b40826c3646050c7702efb63", null ],
    [ "PIO_CONSTRUCTOR", "pio_2spi_8c.html#a83f00a85e354270d40eece124ea95d9d", null ],
    [ "spiGetFn", "pio_2spi_8c.html#a2a5d59c049e07bc098e268005fe5b9e7", null ],
    [ "spiMonitorFn", "pio_2spi_8c.html#af8bd1266903a168ba987cb6b3b81de7c", null ],
    [ "spiSetFn", "pio_2spi_8c.html#a526f9eb30ffe7c69b650c18a9618170d", null ],
    [ "spiSetGet", "pio_2spi_8c.html#a4ab1a5a72e459993c5065d2de0be6ea7", null ],
    [ "commands", "pio_2spi_8c.html#a822ebd265a5e29f6895e6b82c57bba9a", null ],
    [ "monitorButtonsCmd", "pio_2spi_8c.html#a3f264eb279493a0a028009f8b512470e", null ],
    [ "pixiSpiGroup", "pio_2spi_8c.html#ad0b66a3df0e799bb5ef04ad97b917b91", null ],
    [ "spiGetCmd", "pio_2spi_8c.html#ab7b0995a2e2c5bef2da7227df577edcb", null ],
    [ "spiMonitorCmd", "pio_2spi_8c.html#a49eea00c8d98f25fcd21565c72c44e72", null ],
    [ "spiSetCmd", "pio_2spi_8c.html#a7373ab2d20c5828cded7174c353acfe6", null ]
];