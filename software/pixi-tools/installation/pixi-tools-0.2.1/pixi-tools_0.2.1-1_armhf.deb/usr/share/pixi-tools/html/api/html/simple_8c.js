var simple_8c =
[
    [ "globalPixi", "simple_8c.html#ga6352548ef4f2f45d61db8982ab7b0cb8", null ],
    [ "globalPixiAdc", "simple_8c.html#gab3562c90ab0349cdcc824109fadf77f0", null ]
];