var simple_8h =
[
    [ "adcRead", "simple_8h.html#ga111cf60b80523a320b7cdc617c5e851a", null ],
    [ "gpioSetPinMode", "simple_8h.html#ga2bfe91f83c7632438c2822ef9400b711", null ],
    [ "gpioWritePin", "simple_8h.html#gafbb36cce2fe98a8a8fb6be4e4eeb57a4", null ],
    [ "pixiAdcClose", "simple_8h.html#ga6a0173c66eaf9fc32777a317c6cc118e", null ],
    [ "pixiAdcOpen", "simple_8h.html#ga664e47548266dd28465c17c8a1e0a02a", null ],
    [ "pixiAdcOpenOrDie", "simple_8h.html#ga3ed8d3eb65ed923a6757108beb2f7a3b", null ],
    [ "pixiClose", "simple_8h.html#ga8b998b2cc7d3b18b1a8bd60a7b055369", null ],
    [ "pixiOpen", "simple_8h.html#ga660bd5777a92ad206f691755b0be1095", null ],
    [ "pixiOpenOrDie", "simple_8h.html#ga95d9692c25c35404ba9a5178c9ccb016", null ],
    [ "pwmWritePin", "simple_8h.html#ga1bc45e49798f71493b0e9096935bae97", null ],
    [ "pwmWritePinPercent", "simple_8h.html#gaae2c8cc3443e8b2a462b63dd19ec650c", null ],
    [ "registerRead", "simple_8h.html#gaec451d751b94492daaf5d96b81c56500", null ],
    [ "registerWrite", "simple_8h.html#ga403a3050a95356f1b7fddecc68f2115e", null ],
    [ "globalPixi", "simple_8h.html#ga6352548ef4f2f45d61db8982ab7b0cb8", null ],
    [ "globalPixiAdc", "simple_8h.html#gab3562c90ab0349cdcc824109fadf77f0", null ]
];