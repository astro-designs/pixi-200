var adc_8h =
[
    [ "PixiAdcChannels", "adc_8h.html#ggadf764cbdea00d65edcd07bb9953ad2b7a2e4322a09ed4b011cbbf61551cf469af", null ],
    [ "pixi_pixiAdcOpen", "adc_8h.html#ga99a5c4fc8dbe4e1299bf1ccad9f8a4d6", null ],
    [ "pixi_pixiAdcRead", "adc_8h.html#ga4c22e540d3b964bbd4915810818ca3c7", null ]
];