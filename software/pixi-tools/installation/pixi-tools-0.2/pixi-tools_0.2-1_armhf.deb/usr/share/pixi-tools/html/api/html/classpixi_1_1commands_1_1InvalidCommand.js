var classpixi_1_1commands_1_1InvalidCommand =
[
    [ "__init__", "classpixi_1_1commands_1_1InvalidCommand.html#a0c48d666c85808c9a9d237ed5290839e", null ]
];