var classpixi_1_1pixix_1_1Spi =
[
    [ "__init__", "classpixi_1_1pixix_1_1Spi.html#a2340e03fda966c3fa3b301d64a9be654", null ],
    [ "__del__", "classpixi_1_1pixix_1_1Spi.html#a0d7d04572fd1c40aed6dd87d28009383", null ],
    [ "close", "classpixi_1_1pixix_1_1Spi.html#a8d268916f7829270e0cb798f4d34bb58", null ],
    [ "write16", "classpixi_1_1pixix_1_1Spi.html#a4f853343de4c901eb10229cbeff50e61", null ],
    [ "spi", "classpixi_1_1pixix_1_1Spi.html#af37f0914e626daf364f95f8b32c4b02f", null ]
];