var group__PiXiSpi =
[
    [ "pixi_pixiSpiOpen", "group__PiXiSpi.html#ga388c7ded4863bcff5b3aa9b0c1241818", null ],
    [ "pixi_pixiSpiReadValue16", "group__PiXiSpi.html#ga3ecce21dbb187fef0dd24da67e0c2bcc", null ],
    [ "pixi_pixiSpiWriteValue16", "group__PiXiSpi.html#gafaafa308cfaf5f6f29d617214d9b288a", null ],
    [ "pixi_registerRead", "group__PiXiSpi.html#ga8001ea559aae3f2124939db7f1e1d678", null ],
    [ "pixi_registerWrite", "group__PiXiSpi.html#gaf12dff20fbdc19573e63e100ac925803", null ],
    [ "pixi_registerWriteMasked", "group__PiXiSpi.html#ga96e17c9e036fd81ab05d3b49ad813bbb", null ]
];