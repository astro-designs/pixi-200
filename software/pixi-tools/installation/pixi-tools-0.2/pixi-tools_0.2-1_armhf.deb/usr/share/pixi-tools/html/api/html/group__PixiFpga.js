var group__PixiFpga =
[
    [ "pixi_pixiFpgaGetVersion", "group__PixiFpga.html#ga5a3f4bc84f58dd1b7cca90f5da1d3e2b", null ],
    [ "pixi_pixiFpgaLoadBuffer", "group__PixiFpga.html#ga239eedd0597485b9b9ba5a595d5f578e", null ],
    [ "pixi_pixiFpgaLoadFile", "group__PixiFpga.html#gabdee08ccba431774b5492d47fae96af9", null ],
    [ "pixi_pixiFpgaVersionToTime", "group__PixiFpga.html#ga10237dfd7d69154256f334c472ac57f1", null ]
];