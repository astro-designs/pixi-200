var group__PixiGpio =
[
    [ "PixiGpioMode", "group__PixiGpio.html#gadccdf67a8f7cc97181762b198d2cca2f", null ],
    [ "PixiGpioMode", "group__PixiGpio.html#ga8fce565c6555eb634d7f562a8329acef", [
      [ "PixiAdcChannels", "group__PiXiAdc.html#ggadf764cbdea00d65edcd07bb9953ad2b7a2e4322a09ed4b011cbbf61551cf469af", null ],
      [ "PixiGpioAllInput", "group__PixiGpio.html#gga8fce565c6555eb634d7f562a8329acefa33c6e3e1230b92f16eaf27485b07758a", null ],
      [ "PixiGpioAllOutputTiedOut", "group__PixiGpio.html#gga8fce565c6555eb634d7f562a8329acefacd1fdf0c498c2dd4c41a268026c6f5c1", null ],
      [ "PixiGpioAllOutputVfdLcd", "group__PixiGpio.html#gga8fce565c6555eb634d7f562a8329acefa831b830359dfc3006861a31a240f7f75", null ],
      [ "PixiGpio3", "group__PixiGpio.html#gga8fce565c6555eb634d7f562a8329acefa524ef844e8edacc5eae2bdb1fd09b543", null ]
    ] ],
    [ "pixi_pixiGpioSetMode", "group__PixiGpio.html#ga96b98196523de0e46cb6a8eb99e54ef0", null ],
    [ "pixi_pixiGpioSetPinMode", "group__PixiGpio.html#ga29a96629e7370fb517be0a10298cf49b", null ],
    [ "pixi_pixiGpioWritePin", "group__PixiGpio.html#ga45e097e063613dd75f7eada46dead77f", null ]
];