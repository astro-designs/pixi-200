var i_2spi_8h =
[
    [ "PixiSpiChannel", "i_2spi_8h.html#ggabc6126af1d45847bc59afa0aa3216b04a193373f91840cd42386ceecf027297a4", null ],
    [ "PixiAdcSpiChannel", "i_2spi_8h.html#ggabc6126af1d45847bc59afa0aa3216b04ae4764735abcc51bb83311763414654bf", null ],
    [ "PixiSpiSpeed", "i_2spi_8h.html#ggabc6126af1d45847bc59afa0aa3216b04ac9ee3d7ba39070c41803cf59bbc1e8b6", null ],
    [ "PixiAdcSpiSpeed", "i_2spi_8h.html#ggabc6126af1d45847bc59afa0aa3216b04aba82980d87b151406931217be615e4f3", null ],
    [ "PixiSpiEnableWrite8", "i_2spi_8h.html#ggabc6126af1d45847bc59afa0aa3216b04ae18ee91c64ca915c7f5aa66e35f313b8", null ],
    [ "PixiSpiEnableWrite16", "i_2spi_8h.html#ggabc6126af1d45847bc59afa0aa3216b04a760d082b6786e9b618c9e1f5a8f1982e", null ],
    [ "PixiSpiEnableWrite32", "i_2spi_8h.html#ggabc6126af1d45847bc59afa0aa3216b04a47b34a37c1af84044c8f36aae91709b8", null ],
    [ "PixiSpiEnableRead16", "i_2spi_8h.html#ggabc6126af1d45847bc59afa0aa3216b04a10b633f5d3062c25a25f9cd744ded6b6", null ],
    [ "pixi_pixiSpiOpen", "i_2spi_8h.html#ga388c7ded4863bcff5b3aa9b0c1241818", null ],
    [ "pixi_pixiSpiReadValue16", "i_2spi_8h.html#ga3ecce21dbb187fef0dd24da67e0c2bcc", null ],
    [ "pixi_pixiSpiWriteValue16", "i_2spi_8h.html#gafaafa308cfaf5f6f29d617214d9b288a", null ],
    [ "pixi_registerRead", "i_2spi_8h.html#ga8001ea559aae3f2124939db7f1e1d678", null ],
    [ "pixi_registerWrite", "i_2spi_8h.html#gaf12dff20fbdc19573e63e100ac925803", null ],
    [ "pixi_registerWriteMasked", "i_2spi_8h.html#ga96e17c9e036fd81ab05d3b49ad813bbb", null ]
];