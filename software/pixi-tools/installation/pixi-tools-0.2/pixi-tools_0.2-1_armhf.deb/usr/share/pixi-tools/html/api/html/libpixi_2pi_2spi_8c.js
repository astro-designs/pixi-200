var libpixi_2pi_2spi_8c =
[
    [ "pixi_spiClose", "libpixi_2pi_2spi_8c.html#ga44ed12118b7a8bb26db5d0992ccfd042", null ],
    [ "pixi_spiOpen", "libpixi_2pi_2spi_8c.html#ga04ef966a2a22089075d652890721c9c6", null ],
    [ "pixi_spiReadWrite", "libpixi_2pi_2spi_8c.html#ga5ee533f124a5d04a51277a6700bed73a", null ],
    [ "spiDeviceNames", "libpixi_2pi_2spi_8c.html#a1aa0a1d1f49aa442faef5ac4774d4288", null ]
];