var classpixi_1_1commands_1_1CommandError =
[
    [ "__init__", "classpixi_1_1commands_1_1CommandError.html#a35617d51cae8ac1404a942517f22788a", null ]
];