var classpixi_1_1httpd_1_1Server =
[
    [ "__init__", "classpixi_1_1httpd_1_1Server.html#af2877adf1c58d40f0779843570c13363", null ]
];