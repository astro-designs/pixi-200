var dir_d7b181940ff3171c3b9c6adb2da5fe72 =
[
    [ "adc.c", "libpixi_2pixi_2adc_8c.html", "libpixi_2pixi_2adc_8c" ],
    [ "adc.h", "adc_8h.html", "adc_8h" ],
    [ "fpga.c", "libpixi_2pixi_2fpga_8c.html", "libpixi_2pixi_2fpga_8c" ],
    [ "fpga.h", "fpga_8h.html", "fpga_8h" ],
    [ "gpio.c", "libpixi_2pixi_2gpio_8c.html", "libpixi_2pixi_2gpio_8c" ],
    [ "gpio.h", "i_2gpio_8h.html", "i_2gpio_8h" ],
    [ "lcd.c", "libpixi_2pixi_2lcd_8c.html", "libpixi_2pixi_2lcd_8c" ],
    [ "lcd.h", "lcd_8h.html", "lcd_8h" ],
    [ "pwm.c", "pwm_8c.html", "pwm_8c" ],
    [ "pwm.h", "pwm_8h.html", "pwm_8h" ],
    [ "registers.h", "registers_8h.html", "registers_8h" ],
    [ "simple.c", "simple_8c.html", "simple_8c" ],
    [ "simple.h", "simple_8h.html", "simple_8h" ],
    [ "spi.c", "libpixi_2pixi_2spi_8c.html", "libpixi_2pixi_2spi_8c" ],
    [ "spi.h", "i_2spi_8h.html", "i_2spi_8h" ]
];