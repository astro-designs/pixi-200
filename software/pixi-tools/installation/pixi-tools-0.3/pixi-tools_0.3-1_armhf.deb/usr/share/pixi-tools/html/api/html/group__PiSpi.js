var group__PiSpi =
[
    [ "SpiDevice", "structSpiDevice.html", null ],
    [ "SPI_DEVICE_INIT", "group__PiSpi.html#ga86f2239904ddd350f093bf6458cf4d12", null ],
    [ "SpiDevice", "group__PiSpi.html#ga1a9c7a0346103b2913d08d1df0d96142", null ],
    [ "pixi_spiClose", "group__PiSpi.html#ga44ed12118b7a8bb26db5d0992ccfd042", null ],
    [ "pixi_spiOpen", "group__PiSpi.html#ga04ef966a2a22089075d652890721c9c6", null ],
    [ "pixi_spiReadWrite", "group__PiSpi.html#ga5ee533f124a5d04a51277a6700bed73a", null ],
    [ "SpiDeviceInit", "group__PiSpi.html#gab712e3e4d502e0a8616baa489d6d4555", null ]
];