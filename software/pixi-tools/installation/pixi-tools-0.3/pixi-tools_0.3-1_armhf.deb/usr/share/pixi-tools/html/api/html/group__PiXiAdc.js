var group__PiXiAdc =
[
    [ "pixi_pixiAdcOpen", "group__PiXiAdc.html#ga99a5c4fc8dbe4e1299bf1ccad9f8a4d6", null ],
    [ "pixi_pixiAdcRead", "group__PiXiAdc.html#ga4c22e540d3b964bbd4915810818ca3c7", null ]
];