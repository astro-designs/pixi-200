var group__PiXiSimple =
[
    [ "adcRead", "group__PiXiSimple.html#ga111cf60b80523a320b7cdc617c5e851a", null ],
    [ "gpioSetPinMode", "group__PiXiSimple.html#ga2bfe91f83c7632438c2822ef9400b711", null ],
    [ "gpioWritePin", "group__PiXiSimple.html#gafbb36cce2fe98a8a8fb6be4e4eeb57a4", null ],
    [ "pixiAdcClose", "group__PiXiSimple.html#ga6a0173c66eaf9fc32777a317c6cc118e", null ],
    [ "pixiAdcOpen", "group__PiXiSimple.html#ga664e47548266dd28465c17c8a1e0a02a", null ],
    [ "pixiAdcOpenOrDie", "group__PiXiSimple.html#ga3ed8d3eb65ed923a6757108beb2f7a3b", null ],
    [ "pixiClose", "group__PiXiSimple.html#ga8b998b2cc7d3b18b1a8bd60a7b055369", null ],
    [ "pixiOpen", "group__PiXiSimple.html#ga660bd5777a92ad206f691755b0be1095", null ],
    [ "pixiOpenOrDie", "group__PiXiSimple.html#ga95d9692c25c35404ba9a5178c9ccb016", null ],
    [ "pwmWritePin", "group__PiXiSimple.html#ga1bc45e49798f71493b0e9096935bae97", null ],
    [ "pwmWritePinPercent", "group__PiXiSimple.html#gaae2c8cc3443e8b2a462b63dd19ec650c", null ],
    [ "registerRead", "group__PiXiSimple.html#gaec451d751b94492daaf5d96b81c56500", null ],
    [ "registerWrite", "group__PiXiSimple.html#ga403a3050a95356f1b7fddecc68f2115e", null ],
    [ "globalPixi", "group__PiXiSimple.html#ga6352548ef4f2f45d61db8982ab7b0cb8", null ],
    [ "globalPixiAdc", "group__PiXiSimple.html#gab3562c90ab0349cdcc824109fadf77f0", null ]
];