var group__PixiFpga =
[
    [ "pixi_pixiFpgaGetBuildTime", "group__PixiFpga.html#gaee8eefaa11365b14180b9a4e18a4fe78", null ],
    [ "pixi_pixiFpgaGetVersion", "group__PixiFpga.html#ga5a3f4bc84f58dd1b7cca90f5da1d3e2b", null ],
    [ "pixi_pixiFpgaLoadBuffer", "group__PixiFpga.html#ga239eedd0597485b9b9ba5a595d5f578e", null ],
    [ "pixi_pixiFpgaLoadFile", "group__PixiFpga.html#gabdee08ccba431774b5492d47fae96af9", null ],
    [ "pixi_pixiFpgaVersionToTime", "group__PixiFpga.html#ga9db1bb9e7ada76b11a18547f0fdc1a80", null ]
];