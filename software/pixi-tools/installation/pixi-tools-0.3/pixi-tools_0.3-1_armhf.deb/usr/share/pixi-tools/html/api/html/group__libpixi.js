var group__libpixi =
[
    [ "pixi_getLibVersion", "group__libpixi.html#ga79c7bd4369da4002a80700d096143fa9", null ],
    [ "pixi_getPiBoardRevision", "group__libpixi.html#gaaf02a4deb5b4900bf3320e5d0a21223b", null ],
    [ "pixi_getPiBoardVersion", "group__libpixi.html#ga6bd1a557d6172b402a8e4067d880e86e", null ],
    [ "pixi_initLib", "group__libpixi.html#gac2a3c18650b8b2a4eeb44f5411a52a8a", null ]
];