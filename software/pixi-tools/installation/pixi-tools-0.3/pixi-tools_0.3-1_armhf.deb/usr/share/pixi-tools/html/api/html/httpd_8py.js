var httpd_8py =
[
    [ "RequestHandler", "classpixi_1_1httpd_1_1RequestHandler.html", "classpixi_1_1httpd_1_1RequestHandler" ],
    [ "Server", "classpixi_1_1httpd_1_1Server.html", "classpixi_1_1httpd_1_1Server" ],
    [ "commandPath", "httpd_8py.html#a263fa95cdf198bd9f1a44858dee22836", null ],
    [ "debug", "httpd_8py.html#ac92189b7913e9f9bffc18bce4eb80f55", null ],
    [ "info", "httpd_8py.html#a3aa018a851cd31bd73a0bde0d5a0cdb3", null ],
    [ "log", "httpd_8py.html#a30063a20d7c245a1f2b8540c8cf30aac", null ]
];