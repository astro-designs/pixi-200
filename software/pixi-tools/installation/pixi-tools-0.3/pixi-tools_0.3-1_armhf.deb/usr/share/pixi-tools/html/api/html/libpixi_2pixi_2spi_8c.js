var libpixi_2pixi_2spi_8c =
[
    [ "pixi_pixiSpiOpen", "libpixi_2pixi_2spi_8c.html#ga388c7ded4863bcff5b3aa9b0c1241818", null ],
    [ "pixi_registerRead", "libpixi_2pixi_2spi_8c.html#ga8001ea559aae3f2124939db7f1e1d678", null ],
    [ "pixi_registerWrite", "libpixi_2pixi_2spi_8c.html#gaf12dff20fbdc19573e63e100ac925803", null ],
    [ "pixi_registerWriteMasked", "libpixi_2pixi_2spi_8c.html#ga96e17c9e036fd81ab05d3b49ad813bbb", null ],
    [ "readWriteValue16", "libpixi_2pixi_2spi_8c.html#ab0891880f59405ff2f0e2c5f9d089362", null ]
];