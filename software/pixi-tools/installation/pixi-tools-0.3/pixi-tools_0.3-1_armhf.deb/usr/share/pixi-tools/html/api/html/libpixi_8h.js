var libpixi_8h =
[
    [ "pixi_getLibVersion", "libpixi_8h.html#ga79c7bd4369da4002a80700d096143fa9", null ],
    [ "pixi_getPiBoardRevision", "libpixi_8h.html#gaaf02a4deb5b4900bf3320e5d0a21223b", null ],
    [ "pixi_getPiBoardVersion", "libpixi_8h.html#ga6bd1a557d6172b402a8e4067d880e86e", null ],
    [ "pixi_initLib", "libpixi_8h.html#gac2a3c18650b8b2a4eeb44f5411a52a8a", null ]
];