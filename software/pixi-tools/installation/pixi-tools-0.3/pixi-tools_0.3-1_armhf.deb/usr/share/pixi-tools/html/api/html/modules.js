var modules =
[
    [ "libpixi core interface", "group__libpixi.html", "group__libpixi" ],
    [ "Raspberry Pi GPIO interface", "group__PiGpio.html", "group__PiGpio" ],
    [ "Raspberry Pi SPI interface", "group__PiSpi.html", "group__PiSpi" ],
    [ "PiXi ADC / MCP-3204 interface", "group__PiXiAdc.html", "group__PiXiAdc" ],
    [ "PiXi-200 FPGA interface", "group__PixiFpga.html", "group__PixiFpga" ],
    [ "PiXi-200 GPIO interface", "group__PixiGpio.html", "group__PixiGpio" ],
    [ "PiXi-200 LCD panel interface", "group__PixiLcd.html", "group__PixiLcd" ],
    [ "PiXi-200 PWM interface", "group__PixiPWM.html", "group__PixiPWM" ],
    [ "PiXi-200 register maps", "group__PixiRegisters.html", "group__PixiRegisters" ],
    [ "PiXi simple interface", "group__PiXiSimple.html", "group__PiXiSimple" ],
    [ "PiXi SPI interface", "group__PiXiSpi.html", "group__PiXiSpi" ],
    [ "libpixi file utilities", "group__util__file.html", "group__util__file" ],
    [ "libpixi logging interface", "group__util__log.html", "group__util__log" ],
    [ "libpixi string utilities", "group__util__string.html", "group__util__string" ]
];