var namespacepixi =
[
    [ "commands", "namespacepixi_1_1commands.html", "namespacepixi_1_1commands" ],
    [ "httpd", "namespacepixi_1_1httpd.html", "namespacepixi_1_1httpd" ],
    [ "pixix", "namespacepixi_1_1pixix.html", "namespacepixi_1_1pixix" ],
    [ "rover", "namespacepixi_1_1rover.html", null ],
    [ "test", "namespacepixi_1_1test.html", "namespacepixi_1_1test" ]
];