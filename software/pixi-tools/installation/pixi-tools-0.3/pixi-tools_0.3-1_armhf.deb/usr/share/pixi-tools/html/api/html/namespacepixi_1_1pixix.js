var namespacepixi_1_1pixix =
[
    [ "PixiError", "classpixi_1_1pixix_1_1PixiError.html", "classpixi_1_1pixix_1_1PixiError" ],
    [ "Lcd", "classpixi_1_1pixix_1_1Lcd.html", "classpixi_1_1pixix_1_1Lcd" ],
    [ "Spi", "classpixi_1_1pixix_1_1Spi.html", "classpixi_1_1pixix_1_1Spi" ]
];