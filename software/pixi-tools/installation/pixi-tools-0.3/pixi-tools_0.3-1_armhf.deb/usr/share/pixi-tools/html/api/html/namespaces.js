var namespaces =
[
    [ "pixi", "namespacepixi.html", null ]
];