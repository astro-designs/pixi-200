var pixix_8py =
[
    [ "PixiError", "classpixi_1_1pixix_1_1PixiError.html", "classpixi_1_1pixix_1_1PixiError" ],
    [ "Lcd", "classpixi_1_1pixix_1_1Lcd.html", "classpixi_1_1pixix_1_1Lcd" ],
    [ "Spi", "classpixi_1_1pixix_1_1Spi.html", "classpixi_1_1pixix_1_1Spi" ],
    [ "check", "pixix_8py.html#ae05db5a0b20d880da7b5acee47c625bd", null ],
    [ "globalSpi", "pixix_8py.html#a907c3ddab7ded415171bc9ee9b346a72", null ],
    [ "pause", "pixix_8py.html#a3899644f034fcc7e01e6973de8245c13", null ],
    [ "debug", "pixix_8py.html#acdd8455eae5e0522de35316b53948ccd", null ],
    [ "info", "pixix_8py.html#a7c7f6662581a1f73547f17f9b6937727", null ],
    [ "LcdLineLen", "pixix_8py.html#a389baf0bcc0df75b2f7baa1f63f8a826", null ],
    [ "log", "pixix_8py.html#ae6487b1731ac603eaabd037b507f6b86", null ],
    [ "ServoA1", "pixix_8py.html#adf6bb3c5e31a8f4156a5ff690481255a", null ],
    [ "ServoA2", "pixix_8py.html#a20419736c9c56c37e5c6e11c80f81fab", null ],
    [ "ServoB1", "pixix_8py.html#acba2a88885ffbc8e0f3a183d642c0c67", null ],
    [ "ServoB2", "pixix_8py.html#a5b6c3a0bdf390ee12c42af7a688e7fcb", null ],
    [ "spi", "pixix_8py.html#a2671e2fac67142463279c2548bc17d8f", null ]
];