var structBuffer =
[
    [ "memory", "structBuffer.html#ae069ecf239672938e3b9eb69701492d9", null ],
    [ "size", "structBuffer.html#a24e94f119f4b386771c78cf37aaff41b", null ]
];