var structCommand =
[
    [ "description", "structCommand.html#a138b25860069077ad2a1d0100f4cb60d", null ],
    [ "function", "structCommand.html#a65fd0064997d7d374c81031c5128c95e", null ],
    [ "name", "structCommand.html#aaac7db0461198bc84c6bb01e64ae82e3", null ]
];