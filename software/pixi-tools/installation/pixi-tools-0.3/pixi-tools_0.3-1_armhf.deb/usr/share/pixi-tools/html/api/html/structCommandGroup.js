var structCommandGroup =
[
    [ "commands", "structCommandGroup.html#a99f9042352fdf886a8b3c14d3fdd7f61", null ],
    [ "count", "structCommandGroup.html#a3d869018a858f46172aceb084793cff1", null ],
    [ "name", "structCommandGroup.html#a673acc7b168b61101e5cb7adb3d11957", null ],
    [ "nextGroup", "structCommandGroup.html#a19c139214b3e9549d162b29a7ca3ca3a", null ]
];