var structLcdDevice =
[
    [ "spi", "structLcdDevice.html#a1d5048bc65020bff045fb9d12da472ac", null ]
];