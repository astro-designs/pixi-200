var structProperty =
[
    [ "key", "structProperty.html#a909b20714e35e4623bd6c0239b492a9e", null ],
    [ "value", "structProperty.html#a8463c1eedcc7b5f08aeb8fc0d520295b", null ]
];