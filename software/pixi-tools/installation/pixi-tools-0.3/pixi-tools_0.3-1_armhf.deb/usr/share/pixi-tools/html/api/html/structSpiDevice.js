var structSpiDevice =
[
    [ "bitsPerWord", "structSpiDevice.html#a24f42b3079826c01042df7585a0c7e47", null ],
    [ "delay", "structSpiDevice.html#ad3fafda97d0fb1afee9225aca1091d06", null ],
    [ "fd", "structSpiDevice.html#ad0ca9ca076db45dec0bee7b64e916255", null ],
    [ "speed", "structSpiDevice.html#adb0ed785f6a2c2ac91be80b2243e7590", null ]
];