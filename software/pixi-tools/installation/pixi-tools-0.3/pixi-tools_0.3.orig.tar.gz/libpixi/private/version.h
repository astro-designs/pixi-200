static const char LibPixiVersion[] = "0.3";
